<?php
define('WP_AUTO_UPDATE_CORE', false);// This setting is required to make sure that WordPress updates can be properly managed in WordPress Toolkit. Remove this line if this WordPress instance is not managed by WordPress Toolkit anymore.
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_bq3wm' );

/** MySQL database username */
define( 'DB_USER', 'wp_m8xl1' );

/** MySQL database password */
define( 'DB_PASSWORD', '_N90z8cEfR' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '~:]_s-)4AJ301!2(s[[n/ntExO7YY-U(k8A(|;Vnu+rZU5Kl!k3e3aK;_w4m)334');
define('SECURE_AUTH_KEY', 'man1B5Q0gR00@84QL#cJdk3NA9E+*61s10|DG6V]2&7f;xLCO&TV~j[!zK|60h|f');
define('LOGGED_IN_KEY', '3)IthpotM#:mxVE65|MwR#AibxgXQht0741lr:BMLf53I7b9niIqv18vde[17[6!');
define('NONCE_KEY', 'N0I-|88#6H]4S_!JWf/(%;(/Y/Y;1yX97/bFl[ace6u]Umq)L6E6))ROel1y0(#n');
define('AUTH_SALT', ')9K05/)2)%]/4SNI_en1qQ%4-p|e8]_792|_YMn7IMUmy&Z9q6Di/32fu2+l|[;%');
define('SECURE_AUTH_SALT', '[9yHeIo7IZ5FAc/73ed420)9]/r*z2d0*]sN_-7ZOJj[r/2FBqv!r17-UZ5f]@7B');
define('LOGGED_IN_SALT', '8]r296y[51YsU-R+o3LPp1F[F1~p5u9ON1B|0Bu[25R)kU(T92[x15@shFgAh6;8');
define('NONCE_SALT', '5[#3:qnohq07]vv82sN;17U59+6lJBIh07m3:*5@058lsDHI-r@9:dj56A;U*USo');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = '39AcD_';


define('WP_ALLOW_MULTISITE', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
